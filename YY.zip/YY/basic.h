#pragma once

#include <iostream>
#include <string>
#include <conio.h>
#include <Windows.h>
#pragma comment(lib,"WS2_32.lib")
using namespace std;

#define SERVER_IP		"118.126.117.125"//"192.168.142.217" 
#define QUN_LIAO_PORT	2022

bool init();		//��ʼ��������
void login();		//��¼
void uiInit();		//��ʼ��ͼ�λ�����
DWORD WINAPI threadFunRecv(LPVOID pram); 
void editPrint(int col, char ch);
void editPrint(int col, const char* str);
void printMsg(const char* msg);
bool isChinese(char str[], int index);
string GBKToUTF8(const std::string& strGBK);
std::string UTF8ToGBK(const char* strUTF8);
